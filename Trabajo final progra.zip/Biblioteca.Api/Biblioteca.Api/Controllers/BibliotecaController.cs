﻿#nullable disable
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Biblioteca.Api.Data;
using Biblioteca.Api.Modelo;

namespace Biblioteca.Api.Controllers
{
    [Route("[controller]/[action]")]
    public class BibliotecaController : ControllerBase
    {
        private readonly BibliotecaApiContext _context;
        private Libro Libro;
        private Videojuego Videojuego;

        public BibliotecaController(BibliotecaApiContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<IActionResult> ConsultarLibro()
        {
            return Ok(await _context.Libro.ToListAsync());
        }

        [HttpPost]
        public async Task<ActionResult> AgregarLibro(Libro libro)
        {
            _context.Libro.Add(libro);
            await _context.SaveChangesAsync();
            return Ok(libro);
        }

        [HttpPut]
        public async Task<IActionResult> ActualizarLibro(Libro libro)
        {
            _context.Update(libro);
            await _context.SaveChangesAsync();
            return Ok(libro);
        }

        [HttpDelete]
        public async Task<IActionResult> BorrarLibro(Libro libro)
        {
            _context.Remove(libro);
            await _context.SaveChangesAsync();
            return Ok(libro);
        }

        //Videojuego
        [HttpGet]
        public async Task<IActionResult> ConsultarVideojuegos()
        {
            return Ok(await _context.Videojuego.ToListAsync());
        }

        [HttpPost]
        public async Task<ActionResult> AgregarVideojuegos(Videojuego videojuego)
        {
            _context.Videojuego.Add(videojuego);
            await _context.SaveChangesAsync();
            return Ok(videojuego);
        }

        [HttpPut]
        public async Task<IActionResult> ActualizarVideojuegos(Videojuego videojuego)
        {
            _context.Update(videojuego);
            await _context.SaveChangesAsync();
            return Ok(videojuego);
        }

        [HttpDelete]
        public async Task<IActionResult> BorrarVideojuegos(Videojuego videojuego)
        {
            _context.Videojuego.Remove(videojuego);
            await _context.SaveChangesAsync();
            return Ok(videojuego);
        }


    }
}
